﻿module.exports = {
    'adminSecret': 'inthemidistofbattle',
    'userSecret': 'hahahahaha',
    'serviceProviderSecret': 'nowwetry!!!',
    'database': 'mongodb://localhost/bookAPI'
};

//'database': 'mongodb://orahi:orahi123@ds135577.mlab.com:35577/orahidb'